/* ============================================================
   MONEY AND MEANING — Pages JavaScript
   Extra interactivity for inner pages
============================================================ */

/* ── Blog Page: Filter Buttons ── */
const filterBtns = document.querySelectorAll('.filter-btn');
filterBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    filterBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    // When you have real articles, filter here by data-category
  });
});

/* ── Contact Form ── */
const contactForm = document.getElementById('contactForm');
const contactSuccess = document.getElementById('contactSuccess');

if (contactForm) {
  contactForm.addEventListener('submit', function(e) {
    e.preventDefault();
    const btn = this.querySelector('button[type="submit"]');
    btn.textContent = 'Sending...';
    btn.disabled = true;

    setTimeout(() => {
      contactForm.style.display = 'none';
      contactSuccess.style.display = 'block';
    }, 900);
  });
}

/* ── Footer newsletter (pages) ── */
document.querySelectorAll('.footer-nl-form').forEach(form => {
  form.addEventListener('submit', function(e) {
    e.preventDefault();
    const input = this.querySelector('input');
    const btn   = this.querySelector('button');
    if (!input.value.trim()) return;
    btn.textContent = '✓';
    btn.style.background = '#4CAF50';
    input.value = '';
    input.placeholder = 'You\'re subscribed!';
    input.disabled = true;
    btn.disabled = true;
  });
});
